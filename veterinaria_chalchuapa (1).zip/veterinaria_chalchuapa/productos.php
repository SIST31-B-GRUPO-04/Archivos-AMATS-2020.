<style>
	.res{
		width: 80%;
		margin: 0px 10%;
		background: silver;
		border-radius: 0.5em;
		padding: 2% 0%;
	}
</style>
<?php
	include "metodos.php";
	$obj=new Metodos();
	
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
		function cargarcat(id,nombre,desc,precio,exis,cat,prov){
			document.frmprod.nombre.value=nombre;
			document.frmprod.descripcion.value=desc;
			document.frmprod.id.value=id;
			document.frmprod.precio.value=precio;
			document.frmprod.cantidad.value=exis;
			document.frmprod.categoria.value=cat;
			document.frmprod.proveedor.value=prov;
		}
</script>
<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS/producto.css">


</head>
<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>

<div class="modal-dialog text-center">
<div class="col-sm-20 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="">
</div>
<form class="col-12" method=post name=frmprod>
<div class="form-group" id="nombre-group">
<input type="hidden" class="form-control" placeholder="Nombre de la  categoria" name=id>
</div>
<div class="form-group" id="nombre-group">
Nombre del Producto<input type="text" class="form-control" placeholder="Nombre del producto" name=nombre>
</div>
<div class="form-group" id="descripcion-group">
Descripcion:<input type="text" class="form-control" placeholder="Descripcion" name=descripcion>
</div>
<div class="form-group" id="precio-group">
Precio:<input type="number" class="form-control" placeholder="Precio $:" name=precio step=0.01 min=0.01>
</div>
<div class="form-group" id="cantidad-group">
Cantidad:<input type="number" class="form-control" placeholder="Cantidad" name=cantidad min=1>
</div>
<div class="form-group" id="categoria-group">
<label>Categoria:       </label><select name="categoria" id="categoria">

<?php
	echo $obj->cargarselect("categorias");
?>
</select>
</div>
<div class="form-group" id="proveedor-group">
<label>Proveedor:       </label><select name="proveedor" id="proveedor">
<?php
	echo $obj->cargarselect("proveedores");
?>
</select>
</div>
<div id="search">
<form>
<fieldset>
Buscar:<input type="search" placeholder="  Buscar..." name=valor>por <select name=busqueda>
	<option>id de Producto</option>
	<option>nombre de Producto</option>
	<option>Categoria</option>
	<option>Proveedor</option>
</select>
<button type="submit" class="btn btn-primary" name=buscar><i class="fas fa-sing-in-alt"></i>/ Buscar</button>
<i class="fa fa-search"></i>
</button>	
</fieldset>	
</form>

<button type="submit" class="btn btn-primary" name=enviar><i class="fas fa-sing-in-alt"></i>Agregar producto</button>
<button type="submit" class="btn btn-primary" name=actualizar><i class="fas fa-sing-in-alt"></i>  Modificar</button>
<button type="submit" class="btn btn-primary" name=eliminar><i class="fas fa-sing-in-alt"></i>  Eliminar</button>
<button type="submit" class="btn btn-primary" name=mostrar><i class="fas fa-sing-in-alt"></i>Mostrar Datos</button>
</form>


</div>
</div>
</div>
</div>
</body>
</html>
<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli($servername,$username,$password,$dbname);
	
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
	if (isset($_POST["enviar"])) {
		$nombre=$_POST["nombre"];
		$desc=$_POST["descripcion"];
		$pre=$_POST["precio"];
		$cant=$_POST["cantidad"];
		$id=$_POST["id"];
		$cat=$_POST["categoria"];
		$prov=$_POST["proveedor"];
		$sql="INSERT INTO productos VALUES('',(SELECT id_categoria FROM categorias WHERE nombre_categoria='$cat'),(SELECT id_proveedor FROM proveedores WHERE nombre_proveedor='$prov'),'$nombre','$desc',$pre,$cant)";
		$obj->insertar($sql);
		if($obj==true){
			echo "Producto insertado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["actualizar"])){
		$nombre=$_POST["nombre"];
		$desc=$_POST["descripcion"];
		$pre=$_POST["precio"];
		$cant=$_POST["cantidad"];
		$id=$_POST["id"];
		$cat=$_POST["categoria"];
		$prov=$_POST["proveedor"];
		$sql="UPDATE productos SET nombre_producto='$nombre',descripcion='$desc',precio='$pre',existencia='$cant',id_categoria=(SELECT id_categoria FROM categorias WHERE nombre_categoria='$cat'),id_proveedor=(SELECT id_proveedor FROM proveedores WHERE nombre_proveedor='$prov') WHERE id_producto=$id";
		$obj->actualizar($sql);
		if($obj==true){
			echo "Producto Actualizado";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$obj->eliminar("DELETE FROM ventas WHERE id_producto=$id");
		$sql="DELETE FROM productos WHERE id_producto=$id";
		$obj->eliminar($sql);
		if($obj==true){
			echo "Producto eliminado con exito";
		}else{
			echo "error";
		}
	}elseif (isset($_POST["buscar"])) {
		echo "<div class=res>";
		$parametro=$_POST["valor"];
		if($_POST["busqueda"]=="id de Producto"){
			$sql="WHERE id_producto LIKE '%$parametro%'";
			echo $obj->mostrarycargar($sql,"productos");
		}elseif($_POST["busqueda"]=="nombre de Producto"){
			$sql="WHERE nombre_producto LIKE '%$parametro%'";
			echo $obj->mostrarycargar($sql,"productos");
		}elseif($_POST["busqueda"]=="Categoria"){
			$sql="WHERE productos.`id_categoria` LIKE (SELECT id_categoria FROM categorias WHERE nombre_categoria='$parametro')";
			echo $obj->mostrarycargar($sql,"productos");
		}elseif($_POST["busqueda"]=="Proveedor"){
			$sql="WHERE productos.`id_proveedor` LIKE (SELECT id_proveedor FROM proveedores WHERE nombre_proveedor='$parametro')";
			echo $obj->mostrarycargar($sql,"productos");
		}
		echo "</div>";
	}elseif (isset($_POST["mostrar"])) {
		echo "<div class=res>";
		echo $obj->mostraryCargar("","productos");
		echo "</div>";
	}
?>
