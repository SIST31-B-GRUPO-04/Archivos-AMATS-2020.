
<?php
	include "metodos.php";
	$obj=new Metodos();
?>
<!DOCTYPE html>
<html>
<head>
	<style>
		
		.res{
			width: 80%;
			margin: 0px 10%;
			background: silver;
			border-radius: 0.5em;
			padding: 2% 0%;
		}

	</style>
<meta charset="utf-8">
<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS/producto.css">


</head>
<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>

<div class="modal-dialog text-center">
<div class="col-sm-20 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="">
</div>
<form class="col-12" method=post name=frmcat>
<div class="form-group" id="nombre-group">
Dui del Cliente:<select name="dui"><?php echo $obj->cargarselect("clientes");?></select>
</div><br>
<div class="form-group" id="descripcion-group">
Diagnostico:<br><textarea rows=5 cols=35 name=descripcion></textarea><br><br>
Tratamiento recetado:<br><textarea rows=5 cols=35 name=tratamiento></textarea>
</div><br>
<div class="form-group" id="nombre-group">
Fecha de siguiente tratamiento:<input type="date" class="form-control" name=fecha>
</div><br>


<button type="submit" class="btn btn-primary" name=agregar><i class="fas fa-sing-in-alt"></i>  Agregar diagnostico</button>


</form>


</div>
</div>
</div>
</div>
</body>
</html>
<?php
	
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli("localhost","root","","clinica");
	
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}

	if (isset($_POST["agregar"])) {
		$dui=$_POST["dui"];
		$des=$_POST["descripcion"];
		$trat=$_POST["tratamiento"];
		$fecha=$_POST["fecha"];
		$sql="INSERT INTO diagnosticos VALUES('',(SELECT id_cita FROM citas WHERE dui='$dui'),'$dui','$des','$trat','$fecha','activo')";
		if($obj==true){
			echo "registro insertado con exito";
		}else{
			echo "error";
		}
	}/*elseif(isset($_POST["actualizar"])){
		$nombre=$_POST["nombre"];
		$des=$_POST["descripcion"];
		$id=$_POST["id"];
		$sql="UPDATE categorias SET nombre_categoria='$nombre',descripcion='$des' WHERE id_categoria=$id";
		if($conn->query($sql)===TRUE){
			header("Location:categorias.php");
		}else{
			echo "error: ".$sql."<br>".$conn->error;
		}
	}elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$sql="DELETE FROM categorias WHERE id_categoria=$id";
		if($conn->query($sql)===TRUE){
			header("Location:categorias.php");
		}else{
			echo "error: ".$sql."<br>".$conn->error;
		}
	}elseif(isset($_POST["mostrar"])){
		echo "<div class=res>";
		echo $obj->mostraryCargar("","categorias");
		echo "</div>";
	}*/
?>
