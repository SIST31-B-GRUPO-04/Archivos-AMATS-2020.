<?php
	//include "metodos.php";
	//$obj=new Metodos();
	/*echo $obj->mostrar("SELECT id_producto,nombre_producto,productos.`descripcion`,precio,existencia,nombre_categoria,nombre_proveedor FROM productos INNER JOIN categorias ON productos.`id_categoria`=categorias.`id_categoria` INNER JOIN proveedores ON productos.`id_proveedor`=proveedores.`id_proveedor` ORDER BY id_producto");*/
	include "conexion.php";
	$c=new Conexion();
	require('fpdf/fpdf.php');

	class PDF extends FPDF
	{
	// Cabecera de página
	function Header()
	{
	    // Logo
	    $this->Image('CSS/ban.jpg',15,8,180);
	    // Arial bold 15
	    $this->Ln(30);
	    $this->SetFont('Arial','B',18);
	    // Movernos a la derecha
	    $this->Cell(60);
	    // Título
	    $this->Cell(70,10,'Inventario de Productos',0,0,'C');
	    // Salto de línea
	    $this->Ln(20);
	    $this->SetFont('Arial','B',11);
	    $this->Cell(11.5,10,'Id',1,0,'C',0);
		$this->Cell(72,10,'Nombre',1,0,'C',0);
		$this->Cell(20,10,'Desc',1,0,'C',0);
		$this->Cell(20,10,'Precio',1,0,'C',0);
		$this->Cell(20,10,'Existencia',1,0,'C',0);
		$this->Cell(30,10,'Categoria',1,0,'C',0);
		$this->Cell(15,10,'Proveedor',1,1,'C',0);
	}

	// Pie de página
	function Footer()
	{
	    // Posición: a 1,5 cm del final
	    $this->SetY(-15);
	    // Arial italic 8
	    $this->SetFont('Arial','I',8);
	    // Número de página
	    $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
	}
	}
	$conn=new mysqli("localhost","root","","clinica");
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
	$sql="SELECT id_producto,nombre_producto,productos.`descripcion`,precio,existencia,nombre_categoria,nombre_proveedor FROM productos INNER JOIN categorias ON productos.`id_categoria`=categorias.`id_categoria` INNER JOIN proveedores ON productos.`id_proveedor`=proveedores.`id_proveedor` ORDER BY id_producto";
	$res=$c->consultar($sql);


	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',11);
	while ($row=$res->fetch_assoc()) {
		$pdf->Cell(11.5,10,$row['id_producto'],1,0,'C',0);
		$pdf->Cell(72,10,$row['nombre_producto'],1,0,'C',0);
		$pdf->Cell(20,10,$row['descripcion'],1,0,'C',0);
		$pdf->Cell(20,10,$row['precio'],1,0,'C',0);
		$pdf->Cell(20,10,$row['existencia'],1,0,'C',0);
		$pdf->Cell(30,10,$row['nombre_categoria'],1,0,'C',0);
		$pdf->Cell(15,10,$row['nombre_proveedor'],1,1,'C',0);
	}
	$pdf->Output();


?>