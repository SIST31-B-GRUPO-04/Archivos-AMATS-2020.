
<?php
use PHPUnit\Framework\TestCase;
require "pedidos.php";
	final class phpunit extends TestCase
	{
		public function testmultiplicar(){
			$vent=new Ventas();
			$this->assertEquals($vent->totventas(55.8,10),558);
		}
	}
?>