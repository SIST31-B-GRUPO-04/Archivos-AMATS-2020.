<!DOCTYPE html>
<html>
<head>
	<style>
	
	.res{
		width: 70%;
		margin: 0px 15%;
		background: silver;
		border-radius: 0.5em;
		padding: 2% 0%;
	}

</style>
<meta charset="utf-8">
<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
		function cargarcat(id,nombre,tel,email,dir){
			document.frmprov.nombre.value=nombre;
			document.frmprov.tel.value=tel;
			document.frmprov.id.value=id;
			document.frmprov.mail.value=email;
			document.frmprov.dir.value=dir;
		}
</script>
<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS/producto.css">


</head>
<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>

<div class="modal-dialog text-center">
<div class="col-sm-20 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="">
</div>
<form class="col-12" method=post name=frmprov>
<div class="form-group" id="nombre-group">
<input type="hidden" class="form-control" placeholder="Nombre de la  categoria" name=id>
</div>
<div class="form-group" id="nombre-group">
Nombre Prov:<input type="text" class="form-control" placeholder="Nombre: " name=nombre>
</div>
<div class="form-group" id="telefono-group">
Tel:<input type="tel" class="form-control" placeholder="tel: " name=tel>
</div>
<div class="form-group" id="email-group">
E-mail<input type="email" class="form-control" placeholder="e-mail:" name=mail>
</div>
<div class="form-group" id="direccion-group">
Direccion:<input type="text" class="form-control" placeholder="Direccion:" name=dir>
</div>
<fieldset>
Buscar por nombre:<input type="search" placeholder="  Buscar..." name=valor size="12px">
<button type="submit" class="btn btn-primary" name="buscar"><i class="fas fa-sing-in-alt"></i> Buscar</button>
</fieldset>


<button type="submit" class="btn btn-primary" name=enviar><i class="fas fa-sing-in-alt"></i>Agregar proveedor</button>
<button type="submit" class="btn btn-primary" name=actualizar><i class="fas fa-sing-in-alt"></i>  Modificar</button>
<button type="submit" class="btn btn-primary" name=mostrar><i class="fas fa-sing-in-alt"></i>  Mostrar Datos</button>
<button type="submit" class="btn btn-primary" name=eliminar><i class="fas fa-sing-in-alt"></i>  Eliminar</button>

</form>


</div>
</div>
</div>
</div>
</body>
</html>
<?php
	include "metodos.php";
	$obj=new Metodos();
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli($servername,$username,$password,$dbname);
	
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}

	if (isset($_POST["enviar"])) {
		$nombre=$_POST["nombre"];
		$tel=$_POST["tel"];
		$mail=$_POST["mail"];
		$dir=$_POST["dir"];
		$sql="INSERT INTO proveedores VALUES('','$nombre','$tel','$mail','$dir')";
		$obj->insertar($sql);
		if ($obj==true) {
			"Registro agregado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["actualizar"])){
		$nombre=$_POST["nombre"];
		$tel=$_POST["tel"];
		$mail=$_POST["mail"];
		$dir=$_POST["dir"];
		$id=$_POST["id"];
		$sql="UPDATE proveedores SET nombre_proveedor='$nombre',tel='$tel',email='$mail',direccion='$dir' WHERE id_proveedor=$id";
		$obj->actualizar($sql);
		if ($obj==true) {
			"Registro Actualizado";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["mostrar"])){
		echo "<div class=res>";
		echo $obj->mostraryCargar("","proveedores");
		echo "</div>";
	}elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$obj->eliminar("DELETE FROM productos WHERE id_proveedor=$id");
		$sql="DELETE FROM proveedores WHERE id_proveedor=$id";
		$obj->eliminar($sql);
		if($obj==true){
			echo "proveedor eliminado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["buscar"])){
		$parametro=$_POST["valor"];
			$sql="WHERE nombre_proveedor LIKE '%$parametro%'";
			echo $obj->mostrarycargar($sql,"proveedores");
		}

	/*elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$sql="DELETE FROM categorias WHERE id_categoria=$id";
		if($conn->query($sql)===TRUE){
			header("Location:categorias.php");
		}else{
			echo "error: ".$sql."<br>".$conn->error;
		}
	}*/
?>