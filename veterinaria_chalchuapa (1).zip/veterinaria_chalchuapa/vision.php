<!DOCTYPE html>
<html lang="es">
<head>
<title>Vision</title>
<a href="index.php">Inicio</a></li>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">
</head>
<body>
<div id="general">
<div id="lateral">
<img src="imagenes\perico.jpg">
</div>
<div id="banner">
</div>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=vacunacion.php>Vacunacion</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>
	
</div>
<div id="contenido">
<div id="vision">
	<br><br><br>
<h1 align="center">Vision</h1>
<p align="center">ser una empresa con vocación, líder en soluciones veterinarias integrales</p>
<p align="center">y en la prestación de servicios para los animales domésticos, referente para</p>
<p align="center"> nuestros clientes en innovación, excelencia de servicio, conocimiento</p>
<p align="center"> y educación continua, a fin de crear un valor económico y social de forma sostenida</p>
<p align="center"> Apuntando a ser la Primera Veterinaria en Chalchuapa en dar un servicio exclusivo</p>
<p align="center"> y de calidad en el Servicio de Emergencias las 24 horas para sus amadas mascotas</p>
<p align="center"> orientadas al bienestar, ya que contamos con experiencia de muchos años en la práctica clínica.</p>
<br align="center">
<img src="imagenes\vi.jpg">
</div>
<img src="imagenes\vb.jpg">
<img src="imagenes\d.jpg">
</div>
<div id="footer">
<p><h2>Clinica Veterinaria Chalchuapa| © 20 Todos los derechos reservados | Políticas de privacidad
 </h2></p>
</div>
</div>
</body>
</html>