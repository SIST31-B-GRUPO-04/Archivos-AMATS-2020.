<!DOCTYPE html>
<html lang="es">
<head>
<title>Mision</title>
<a href="index.php">Inicio</a></li>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">
</head>
<body>
<div id="general">
<div id="lateral">
<img src="imagenes\mi.jpg">
</div>
<div id="banner">
</div>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=clinica.php>Clinica</a></li>
<li> <a href=peluqueria.php>Peluqueria</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>
	
</div>
<div id="contenido">
<div id="Mision">
	<br><br><br>
<h1 align="center">Mision</h1>
<p align="center"> ofrecer a nuestros clientes</p>
<p align="center"> de los mejores productos y de las soluciones de más valor.</p>
<p align="center"> Nos respaldamos en nuestra cultura de la innovación y capacitación continua</p>
<p align="center"> y de nuestra responsabilidad social, buscando la mayor satisfacción posible</p>
<p align="center"> ofreciendo una atención médica de calidad, en un ambiente de respeto hacia nuestros pacientes</p> <p align="center">y clientes</p>
<br>
<img src="imagenes\mision.jpg">
</div>
<img src="imagenes\asd.jpg">
<img src="imagenes\c.jpg">
</div>
<div id="footer">
<p><h2>Clinica Veterinaria Chalchuapa| © 20 Todos los derechos reservados | Políticas de privacidad
 </h2></p>
</div>
</div>
</body>
</html>