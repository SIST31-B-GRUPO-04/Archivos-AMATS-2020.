<?php
	session_start();
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	include "conexion.php";
	$c=new Conexion();

	if (isset($_POST["enviar"])){
		$usuario=$_POST["usuario"];
		$contra=$_POST["contra"];
		$sql="SELECT tipo from usuarios WHERE alias='$usuario' and clave='$contra'";
		$resultado=$c->consultar($sql);
		$cant=mysqli_num_rows($resultado);
		echo $usuario.",".$contra.",".$cant;
		if ($cant==0) {
			header("Location:login.php");

		}
		$fila=$resultado->fetch_array(MYSQLI_NUM);
		$nivel=$fila[0];
		echo "$nivel";
		if ($nivel=="administrador") {
			$_SESSION["usuario"]["nombre"]=$usuario;
			$_SESSION["usuario"]["nivel"]=$nivel;
			header("Location:index.php");
		}elseif($nivel=="user"){
			$_SESSION["usuario"]["nombre"]=$usuario;
			$_SESSION["usuario"]["nivel"]=$nivel;
			header("Location:index.php");
		}else{
			header("Location:login.php");
		}
	}
	if(isset($_REQUEST["cerrar"])){
		session_destroy();
		header("Location:index.php");
	}
?>
