<!DOCTYPE html>
<html lang="es">
<head>
<title>Alimentos</title>
<a href="ejemplo.html">Inicio</a></li>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">
<link rel="stylesheet" type="text/css" href="CSS\tienda.css">
<link href="https://fonts.googleapis.com/css?famaly=Lato" rel="stylesheet">

</head>
<body>
<div id="general">

<div id="banner">
</div>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=vacunacion.php>Vacunacion</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>
</div>
<br><br><br>

<div id="contenedor">
<section class="Productos">
<br>
<h1 align="center">Alimentos</h1>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\a19.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$25.00</h2>
<br>
<p>Pro plan–Active mind raza mediana</p>
<p>grade(3 kg)</p>

</section>
</section>

<section class="productos-item">
<img src="Imagenes\a2.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$8.97</h2>
<p>Royal canin Hepatic</p>
<p>(420 gr)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a3.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$4.97</h2>
<p>Royal canin lata-Renal</p>
<p>(410 gr)</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\a4.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$4.50</h2>
<p>Pro plan lata – Adulto Sensitive skin & stomach </p>
<p>(368 gr)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a5.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$4.50</h2>
<p>Pro plan lata – Adulto 7+ Beef & Rice</p>
<p>(368 gr)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a6.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$58.00</h2>
<p>Nupec–cachorro raza pequeña</p>
<p>(8kg)</p>
</section>
</section>
</div>
</section>


<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\a7.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$13.50</h2>
<p>Nupec- Adulto raza grande </p>
<p>(2kg)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a8.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$15.50</h2>
<p>Nupec – Cachorro raza grande </p>
<p>(2kg)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a9.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$33.90</h2>
<p>Royal canin – Hypoallergenic </p>
<p>(2kg)</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\a10.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$25.00</h2>
<p>Pro plan – Active mind raza mediana/grade</p>
<p>(3kg)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a11.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$12.43</h2>
<p>Royal canin – Stater mother & baby dog Max </p>
<p>(1kg)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a12.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$9.89</h2>
<p>Royal canin – puppy medium </p>
<p>(1kg)</p>
</section>
</section>
</div>
</section>
</section>
</section>
<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\a13.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$24.86</h2>
<p>Royal canin – Feline obesity  </p>
<p>(1.5kg)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a14.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$24.00</h2>
<p>Propac ultimates cats and kittens</p>
<p>(2kg)</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\a15.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$77.50</h2>
<p>Propac Mature</p>
<p>(12kg)</p>
</section>
</section>
</div>
</section>

</body>
</div>
</div>
</body>

</html>
