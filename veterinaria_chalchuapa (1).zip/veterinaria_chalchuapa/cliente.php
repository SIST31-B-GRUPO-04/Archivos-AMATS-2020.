<style>
	
	.res{
		width: 60%;
		margin: 0px auto;
		background: silver;
		border-radius: 0.5em;
		padding: 2% 0%;
	}

</style>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
		function cargarcat(id,nombre,apell,tel){
			document.frmusu.nombre.value=nombre;
			document.frmusu.apell.value=apell;
			document.frmusu.tel.value=tel;
			document.frmusu.id.value=id;
		}
</script>
<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS/producto.css">


</head>
<body class=ltera>
	<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>
<div class="modal-dialog text-center">
<div class="col-sm-20 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="">
</div>
<form class="col-12" method=post name=frmusu>
<div class="form-group" id="nombre-group">
<label>Dui:</label><input type="text" class="form-control" placeholder="Dui" name=id>
</div>
<div class="form-group" id="nombre-group">
<label>Nombre:</label><input type="text" class="form-control" placeholder="Nombre" name=nombre>
</div>
<div class="form-group" id="nombre-group">
<label>Apellido:</label><input type="text" class="form-control" placeholder="Apellido" name=apell>
</div>
<div class="form-group" id="tel-group">
<label>Telefono:</label><input type="tel" class="form-control" placeholder="Telefono" name=tel>
</div>
<div id="search">
<form>
<fieldset>
Buscar:<input type="search" placeholder="  Buscar..." name=valor>por:<select name=busqueda>
	<option>Nombre</option>
	<option>Nombre de usuario</option>
	<option>DUI</option>
</select>
<button type="submit" class="btn btn-primary" name=buscar><i class="fas fa-sing-in-alt"></i>/ Buscar</button>
<i class="fa fa-search"></i>
</button>	
</fieldset>	
</form>

<button type="submit" class="btn btn-primary" name=enviar><i class="fas fa-sing-in-alt"></i>/  Agregar</button>
<button type="submit" class="btn btn-primary" name=actualizar><i class="fas fa-sing-in-alt"></i>/  Actualizar</button>
<button type="submit" class="btn btn-primary" name=eliminar><i class="fas fa-sing-in-alt"></i>/  Eliminar</button>
<button type="submit" class="btn btn-primary" name=mostrar><i class="fas fa-sing-in-alt"></i>Mostrar Datos</button>

</form>

</div>


</div>
</div>
</div>
</div>
</body>
</html>
<?php
	include "metodos.php";
	$obj=new Metodos();
	$conn=new mysqli("localhost","root","","clinica");
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
	if (isset($_POST["enviar"])) {
		$id=$_POST["id"];
		$nombre=$_POST["nombre"];
		$ape=$_POST["apell"];
		$tel=$_POST["tel"];
		$sql="INSERT INTO clientes VALUES('$id','$nombre','$ape','$tel','','')";
		$obj->insertar($sql);
		if ($obj==true) {
			echo "Registro guardado";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["actualizar"])){
		$nombre=$_POST["nombre"];
		$ape=$_POST["apell"];
		$tel=$_POST["tel"];
		$id=$_POST["id"];
		$sql="UPDATE clientes SET nombre_cliente='$nombre',apellido_client='$ape',tel='$tel' WHERE id_cliente='$id'";
		$obj->actualizar($sql);
		if ($obj==true) {
			echo "Registro actualizado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$sql="DELETE FROM clientes WHERE id_cliente='$id'";
		$obj->eliminar($sql);
		if ($obj==true) {
			echo "Registro eliminado";
		}else{
			echo "error";
		}
	}elseif (isset($_POST["buscar"])) {
		echo "<div class=res>";
		$parametro=$_POST["valor"];
		if($_POST["busqueda"]=="Nombre"){
			$sql="WHERE nombre_cliente LIKE '%$parametro%' OR apellido_client LIKE '%$parametro%'";
			echo $obj->mostrarycargar($sql,"clientes");
		}elseif($_POST["busqueda"]=="DUI"){
			$sql="WHERE id_cliente LIKE '%$parametro%'";
			echo $obj->mostrarycargar($sql,"clientes");
		}/*elseif($_POST["busqueda"]=="Proveedor"){
			$sql="WHERE productos.`id_proveedor` LIKE (SELECT id_proveedor FROM proveedores WHERE nombre_proveedor='$parametro')";
			echo $obj->mostrarycargar($sql,"productos");
		}*/
		echo "</div>";
	}elseif (isset($_POST["mostrar"])) {
		echo "<div class=res>";
		echo $obj->mostraryCargar("","clientes");
		echo "</div>";
	}
?>