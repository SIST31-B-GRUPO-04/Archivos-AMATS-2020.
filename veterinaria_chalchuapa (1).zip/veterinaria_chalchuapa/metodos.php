<style>
	.h{
		color: white;
		background: black;
	
	}
	.tabla{
		border-radius: 0.5em;
		background: white;
	}
	.j{
		background: blue;
		color: white;
	}
	.j a{
		color: black;
	}
</style>
<!DOCTYPE html>
<html>
<head>
	<title></title>

<link rel="stylesheet" href="CSS\estilo.css">
</head>
<body>

<?php
	include "conexion.php";
	class Metodos{
		protected $c;
		public function Metodos(){
			$this->c=new Conexion();
		}
		public function insertar($sql){
			$this->c->ejecutar($sql);
		}
		public function actualizar($sql){
			$this->c->ejecutar($sql);
		}
		public function eliminar($sql){
			$this->c->ejecutar($sql);
		}
		
		public function mostrar($sql){
			$resultado=$this->c->consultar($sql);
			$ncampos=mysqli_num_fields($resultado);
			$tabla="<table align=center class=t>";
			$tabla.="<tr>";
			while ($encabezado=mysqli_fetch_field($resultado)) {
			$tabla.="<td align=center class=h><b>".$encabezado->name."</td></b>";
			}
			echo "</tr>";
			for($i=0;$i<$ncampos;$i++){
				while($fila=mysqli_fetch_row($resultado)){
					$tabla.="<tr>";
					for($col=0;$col<$ncampos;$col++){
						$tabla.="<td align=center class=j>".$fila[$col]."</td>";
					}
				}
			}
			$tabla.="</table>";
			return $tabla;

		}
		public function cargar($tabla){
			$sess=$_SESSION["usuario"]["nombre"];
			$sql="SELECT * FROM $tabla where alias='$sess'";
			$resultado=$this->c->consultar($sql);
			$ncampos=mysqli_num_fields($resultado);
		
				
				while($fila=mysqli_fetch_row($resultado)){
					echo "<b><a href="."javascript:cargar('$fila[1]','$fila[2]','$fila[4]','$fila[5]','$fila[7]','$fila[8]')"." class=h>Cargar Datos</a></b>";
				}
			
				
		}

		public function mostraryCargar($condicion,$tabl){
			if($tabl=="productos"){
				$resultado=$this->c->consultar("SELECT id_producto,nombre_producto,productos.`descripcion`,precio,existencia,nombre_categoria,nombre_proveedor FROM productos INNER JOIN categorias ON productos.`id_categoria`=categorias.`id_categoria` INNER JOIN proveedores ON productos.`id_proveedor`=proveedores.`id_proveedor` $condicion ORDER BY id_producto");
			}else{
				$resultado=$this->c->consultar("SELECT * FROM $tabl $condicion");
			}
			
			$ncampos=mysqli_num_fields($resultado);
			$tabla="<table align=center class=t>";
			$tabla.="<tr>";
			while ($encabezado=mysqli_fetch_field($resultado)) {
				$tabla.="<td align=center class=h><b>".$encabezado->name."</td></b>";
			}
			$tabla.="<td class=h><b>Acciones</td></b></tr>";
			for($i=0;$i<$ncampos;$i++){
				while($fila=mysqli_fetch_row($resultado)){
					$tabla.="<tr>";
					for($col=0;$col<$ncampos;$col++){
						$tabla.="<td align=center class=j>".$fila[$col]."</td>";
					}
						if($tabl=="categorias"){
							$tabla.="<td class=j><b>
							<a href="."javascript:cargarcat('$fila[0]','$fila[1]','$fila[2]')".">Cargar Datos</a></td></b>";
						}elseif($tabl=="proveedores"){
							$tabla.="<td class=j><b>
							<a href="."javascript:cargarcat('$fila[0]','$fila[1]','$fila[2]','$fila[3]','$fila[4]')".">Cargar Datos</a></td></b>";
						}elseif($tabl=="productos"){
							$tabla.="<td class=j><b>
							<a href="."javascript:cargarcat('$fila[0]','$fila[1]','$fila[2]','$fila[3]','$fila[4]','$fila[5]','$fila[6]')".">Cargar Datos</a></td></b>";
						}elseif($tabl=="usuarios"){
							$tabla.="<td class=j><b>
							<a href="."javascript:cargarcat('$fila[0]','$fila[1]','$fila[2]','$fila[3]','$fila[4]','$fila[5]','$fila[6]','$fila[7]','$fila[8]')".">Cargar Datos</a></td></b>";
						}elseif($tabl=="pedidos"){
							$tabla.="<td class=j><b>
							<form method=post>
							<a href="."javascript:cargarcat('$fila[1]')"."><input type=submit name=verdet value='Ver Detalle'></a></td></b>";
						}elseif($tabl=="clientes"){
							$tabla.="<td class=j><b>
							<form method=post>
							<a href="."javascript:cargarcat('$fila[0]','$fila[1]','$fila[2]','$fila[3]')".">Cargar Datos</a></td></b>";
						}
					$tabla.="</tr>";
				
				}
			}
			$tabla.="</table>";
			return $tabla;
		}

		public function cargarselect($tabla){
			if($tabla=="categorias"){
			$resultado=$this->c->consultar("SELECT nombre_categoria FROM $tabla");
			}elseif($tabla=="proveedores"){
			$resultado=$this->c->consultar("SELECT nombre_proveedor FROM $tabla");
			}elseif($tabla=="productos"){
			$resultado=$this->c->consultar("SELECT nombre_producto FROM $tabla WHERE existencia>10");
			}elseif($tabla=="clientes"){
			$resultado=$this->c->consultar("SELECT id_cliente FROM $tabla");
			}
			$select="";
			$ncampos=mysqli_num_fields($resultado);
			for($i=0;$i<$ncampos;$i++){
				while($fila=mysqli_fetch_row($resultado)){
					for($col=0;$col<$ncampos;$col++){
						$select.="<option>".$fila[$col]."</option>";
					}
				}
			}

			return $select;
		}
	}
?>


</body>
</html>