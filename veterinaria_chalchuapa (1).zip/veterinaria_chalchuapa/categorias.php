

<!DOCTYPE html>
<html>
<head>
	<style>
		
		.res{
			width: 80%;
			margin: 0px 10%;
			background: silver;
			border-radius: 0.5em;
			padding: 2% 0%;
		}

	</style>
<meta charset="utf-8">
<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
		function cargarcat(id_categoria,nombre,descripcion){
			document.frmcat.nombre.value=nombre;
			document.frmcat.descripcion.value=descripcion;
			document.frmcat.id.value=id_categoria;
		}
	</script>
<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS/producto.css">


</head>
<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>


<div class="modal-dialog text-center">
<div class="col-sm-20 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="">
</div>
<form class="col-12" method=post name=frmcat>
<div class="form-group" id="nombre-group">
<input type="hidden" class="form-control" placeholder="Nombre de la  categoria" name=id>
</div>
<div class="form-group" id="nombre-group">
Nombre de la  categoria:<input type="text" class="form-control" placeholder="Nombre de la  categoria" name=nombre>
</div>
<div class="form-group" id="descripcion-group">
Descripcion:<br><textarea rows=5 cols=35 name=descripcion></textarea>
</div>
<fieldset>
Buscar por nombre:<input type="search" placeholder="  Buscar..." name=valor size="12px">
<button type="submit" class="btn btn-primary" name="buscar"><i class="fas fa-sing-in-alt"></i> Buscar</button>
</fieldset>
<button type="submit" class="btn btn-primary" name=agregar><i class="fas fa-sing-in-alt"></i>  Agregar Categoria</button>
<button type="submit" class="btn btn-primary" name=actualizar><i class="fas fa-sing-in-alt"></i>  Modificar</button>
<button type="submit" class="btn btn-primary" name=mostrar><i class="fas fa-sing-in-alt"></i>  Mostrar Datos</button>
<button type="submit" class="btn btn-primary" name=eliminar><i class="fas fa-sing-in-alt"></i>  Eliminar</button>

</form>


</div>
</div>
</div>
</div>
</body>
</html>
<?php
	include "metodos.php";
	$obj=new Metodos();
	if (isset($_POST["agregar"])) {
		$nombre=$_POST["nombre"];
		$des=$_POST["descripcion"];
		$sql="INSERT INTO categorias VALUES('','$nombre','$des')";
		$obj->insertar($sql);
		if($obj==true){
			echo "Registro guardado";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["actualizar"])){
		$nombre=$_POST["nombre"];
		$des=$_POST["descripcion"];
		$id=$_POST["id"];
		$sql="UPDATE categorias SET nombre_categoria='$nombre',descripcion='$des' WHERE id_categoria=$id";
		$obj->actualizar($sql);
		if ($obj==true) {
			echo "Registro actualizado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$sql="DELETE FROM categorias WHERE id_categoria=$id";
		$obj->eliminar($sql);
		if ($obj==true) {
			echo "Registro eliminado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["mostrar"])){
		echo "<div class=res>";
		echo $obj->mostraryCargar("","categorias");
		echo "</div>";
	}elseif(isset($_POST["buscar"])){
		$parametro=$_POST["valor"];
			$sql="WHERE nombre_categoria LIKE '%$parametro%'";
			echo $obj->mostrarycargar($sql,"categorias");
		}
?>
