<style>
	
	.res{
		width: 80%;
		margin: 0px 10%;
		background: silver;
		border-radius: 0.5em;
		padding: 2% 0%;
	}
</style>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
		function cargarcat(id,nombre,apell,tipo,tel,mail,estado,user,clave){
			document.frmusu.nombre.value=nombre;
			document.frmusu.apell.value=apell;
			document.frmusu.tel.value=tel;
			document.frmusu.mail.value=mail;
			document.frmusu.id.value=id;
			document.frmusu.usuario.value=user;
			document.frmusu.contra.value=clave;
		}
</script>
<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS/producto.css">


</head>
<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>

<div class="modal-dialog text-center">
<div class="col-sm-20 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="">
</div>
<form method=post name=frmusu class="col-12">
<div class="form-group" id="nombre-group">
<input type="hidden" class="form-control" placeholder="Nombre de la  categoria" name=id>
</div>
<div class="form-group" id="nombre-group">
Nombre:<input type="text" class="form-control" placeholder="Nombre" name=nombre>
</div>
<div class="form-group" id="nombre-group">
Apellido:<input type="text" class="form-control" placeholder="Apellido" name=apell>
</div>
<div class="form-group" id="e-mail-group">
E-mail:<input type="email" class="form-control" placeholder="e-mail" name=mail>
</div>
<div class="form-group" id="tel-group">
Telefono:<input type="tel" class="form-control" placeholder="Telefono" name=tel>
</div>
<div class="form-group" id="nombre-group">
Nombre de Usuario<input type="text" class="form-control" placeholder="Nombre de usuario" name=usuario>
</div>
<div class="form-group" id="contraseña-group">
Contraseña:<input type="pass" class="form-control" placeholder="Contraseña" name=contra>
</div>
<div id="search">
<fieldset>
Buscar:<input type="search" placeholder="  Buscar..." name=valor size="12px">por:<select name=busqueda>
	<option>Nombre</option>
	<option>Nombre de usuario</option>
	<option>Tipo</option>
</select>
<button type="submit" class="btn btn-primary" name="buscar"><i class="fas fa-sing-in-alt"></i> Buscar</button>
</fieldset>
<button type="submit" class="btn btn-primary" name="enviar"><i class="fas fa-sing-in-alt"></i>  Agregar</button>
<button type="submit" class="btn btn-primary" name="actualizar"><i class="fas fa-sing-in-alt"></i>  Actualizar</button>
<button type="submit" class="btn btn-primary" name="eliminar"><i class="fas fa-sing-in-alt"></i>  Eliminar</button>
<button type="submit" class="btn btn-primary" name="mostrar"><i class="fas fa-sing-in-alt"></i>  Mostrar 
datos</button>
<button type="submit" class="btn btn-primary" name="el"><i class="fas fa-sing-in-alt"></i>  Mostrar Eliminados</button>





</form>

</div>


</div>
</div>
</div>
</div>
</body>
</html>
<?php
	include "metodos.php";
	$obj=new Metodos();
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli($servername,$username,$password,$dbname);
	
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
	if (isset($_POST["enviar"])) {
		$nombre=$_POST["nombre"];
		$ape=$_POST["apell"];
		$tel=$_POST["tel"];
		$mail=$_POST["mail"];
		$usuario=$_POST["usuario"];
		$clave=$_POST["contra"];
		$sql="INSERT INTO usuarios VALUES('','$nombre','$ape','user','$tel','$mail','activo','$usuario','$clave')";
		$obj->insertar($sql);
		if($obj==true){
			echo "Usuario insertado con exito";
		}else{
			echo "eror";
		}
	}elseif(isset($_POST["actualizar"])){
		$nombre=$_POST["nombre"];
		$ape=$_POST["apell"];
		$tel=$_POST["tel"];
		$mail=$_POST["mail"];
		$usuario=$_POST["usuario"];
		$clave=$_POST["contra"];
		$id=$_POST["id"];
		$sql="UPDATE usuarios SET nombre_usuario='$nombre',ap_usuario='$ape',tel='$tel',email='$mail',alias='$usuario',estado='activo',clave='$clave' WHERE id_usuario=$id";
		$obj->actualizar($sql);
		if ($obj==true) {
			echo "Usuario actualizado con exito";
		}else{
			echo "error";
		}
	}elseif(isset($_POST["eliminar"])){
		$id=$_POST["id"];
		$sql="UPDATE usuarios set estado='eliminado' WHERE id_usuario=$id";
		$obj->actualizar($sql);
	}elseif (isset($_POST["buscar"])) {
		echo "<div class=res>";
		$parametro=$_POST["valor"];
		if($_POST["busqueda"]=="Nombre"){
			$sql="WHERE nombre_usuario LIKE '%$parametro%' OR ap_usuario LIKE '%$parametro%' and estado='activo'";
			echo $obj->mostrarycargar($sql,"usuarios");
		}elseif($_POST["busqueda"]=="Nombre de usuario"){
			$sql="WHERE alias LIKE '%$parametro%' and estado='activo'";
			echo $obj->mostrarycargar($sql,"usuarios");
		}elseif($_POST["busqueda"]=="Tipo"){
			$sql="WHERE tipo LIKE '%$parametro%' and estado='activo'";
			echo $obj->mostrarycargar($sql,"usuarios");
		}/*elseif($_POST["busqueda"]=="Proveedor"){
			$sql="WHERE productos.`id_proveedor` LIKE (SELECT id_proveedor FROM proveedores WHERE nombre_proveedor='$parametro')";
			echo $obj->mostrarycargar($sql,"productos");
		}*/
		echo "</div>";
	}elseif (isset($_POST["mostrar"])) {
		echo "<div class=res>";
		echo $obj->mostraryCargar("WHERE estado='activo'","usuarios");
		echo "</div>";
	}elseif (isset($_POST["el"])) {
		echo "<div class=res>";
		echo $obj->mostraryCargar("WHERE estado='eliminado'","usuarios");
		echo "</div>";
	}
?>
