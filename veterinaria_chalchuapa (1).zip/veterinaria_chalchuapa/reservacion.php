
<?php
	session_start();
	include "metodos.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=lato:400,900"
rel="stylesheet">
<link rel="stylesheet"./css/reset.css>
<link rel="stylesheet" type="text/css" href="CSS\reservacion.css">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">


<title>Reservacion</title>
</head>

<?php
	/*if(isset($_SESSION["usuario"])){
		if($_SESSION["usuario"]["nivel"]=='administrador'|| $_SESSION["usuario"]["nivel"]=='user'){
			echo "Bienvenido ".$_SESSION["usuario"]["nombre"]."(".$_SESSION["usuario"]["nivel"].")";
			echo "<a href='acceso.php?cerrar=true'>Cerrar Sesion</a>";
		}else{
			header("Location:login.php");
		}
	}else{
		header("Location:login.php");
		}*/
?>

<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=vacunacion.php>Vacunacion</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>	
</div>
<div class="container">
<div class="form_top">
<h2>Reservacion de <span>Cita </span></h2>
</div>
<form class="form_reg" action="" method=post>

<input class="input" type="text"placeholder="&#128100; DUI" required autofocus name=dui>

<input class="input" type="text"placeholder="&#128100; Nombre  de propietario" required autofocus name=nprop>

<input class="input" type="text"placeholder="&#128100; Apellido  de propietario" required name=apell>

<input class="input" type="tel"placeholder="&#128222; Telefono" required name=cel>

<input class="input" type="text"placeholder="&#128137; Nombre  de la mascota" required autofocus name=nmascota>

<label for="">Sexo</label>
<input type="radio" name="sexo" value="Baron" checked>Baron

<input type="radio" name="sexo" value="Hembra">Hembra

<label for="tipo_mascota">Tipo de Mascota</label>
<select name="tipo_mascota" id="tipo_mascota">
<option value="canino">Canino</option>
<option value="felino">Felino</option>
<option value="aves">Aves</option>
<option value="peces">Peces</option>
</select>

<input class="input" type="edad"placeholder="&#128137;Edad de la mascota" required name=edad>

<input class="input" type="date"placeholder="Dia" required name=fecha>

<input class="input" type="time"placeholder="Hora" required name=hora>

<div class="btn_form">
<input class="btn_submit" type="submit" value="Enviar" name=enviar>
<input class="btn_reset" type="reset" value="Borrar">
</div>
</form>
</div>
</body>
</html>
<?php
	$obj=new Metodos();
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli($servername,$username,$password,$dbname);
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
	if(isset($_POST["enviar"])){
		$nombre=$_POST['nprop'];
		$apell=$_POST['apell'];
		$tel=$_POST['cel'];
		$nmas=$_POST['nmascota'];
		$sexo=$_POST['sexo'];
		$tipo=$_POST['tipo_mascota'];
		$edad=$_POST['edad'];
		$fecha=$_POST['fecha'];
		$hora=$_POST['hora'];
		$dui=$_POST['dui'];
		$sql="INSERT INTO citas VALUES('','$nombre','$apell','$tel','$nmas','$sexo','$tipo','$edad','$fecha','$hora','$dui','pendiente')";
			 $obj->insertar($sql);
			echo $obj->mostrar("select * from citas");
	}
?>