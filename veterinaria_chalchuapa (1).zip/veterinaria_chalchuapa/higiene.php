<!DOCTYPE html>
<html lang="es">
<head>
<title>Higiene y Aseo</title>
<a href="ejemplo.html">Inicio</a></li>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">
<link rel="stylesheet" type="text/css" href="CSS\tienda.css">
<link href="https://fonts.googleapis.com/css?famaly=Lato" rel="stylesheet">

</head>
<body>
<div id="general">

<div id="banner">
</div>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=vacunacion.php>Vacunacion</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>
</div>
<br><br><br>

<div id="contenedor">
<section class="Productos">
<br>
<h1 align="center">Higiene y Aseo</h1>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\h1.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$15.00</h2>
<br>
<p>Shampoo Mv. Desma Antiricotico</p>
<p> &antiseptico</p>

</section>
</section>

<section class="productos-item">
<img src="Imagenes\h2.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$20.00</h2>
<p>Shampoo Mv.Desma </p>
<p> Antipruriginoso</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h3.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$12.00</h2>
<p>Shampoo Mv. Desma </p>
<p>Piel sensible (16) onz</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\h4.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$15.00</h2>
<p>Shampoo Mv. Desma </p>
<p>Ectoparasiticido (16) onz </p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h5.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo Avena y miel </p>
<p>Collie (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h6.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo Extra fuerte Collie 16 onz</p>
<p>Collie (16)onz</p>
</section>
</section>
</div>
</section>


<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\h7.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo Acondicionador  </p>
<p>Avena y miel (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h8.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo Derma Collie   </p>
<p> (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h9.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo para Cachorro Collie  </p>
<p> (16) onz</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\h10.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo Pelo Blanco    </p>
<p>Collie (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h11.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$12.50</h2>
<p>Shampoo Dermatitis   </p>
<p> & piel sensible (20) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h12.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$4.50</h2>
<p>Shampoo Natural Pet Shampoo   </p>
<p>y acondicionador  (16) onz</p>
</section>
</section>
</div>
</section>
</section>
</section>
<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\h13.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$5.50</h2>
<p>Shampoo Natural Pet   </p>
<p>Anti pulgas  (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h14.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo Natural pet   </p>
<p>extracto coco (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\h15.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$6.50</h2>
<p>Shampoo    </p>
<p>Natural Pet Avena (1) galon</p>
</section>
</section>
</div>
</section>

</body>
</div>
</div>
</body>

</html>