<!DOCTYPE html>
<html lang="es">
<head>
<title>Inicio</title>
<script src="https://kit.fontawesome.com/3f0ec37d5d.js" crossorigin="anonymous"></script>
<meta charset="utf-8">
<link rel="stylesheet" href="CSS\estilo.css">
<link rel="stylesheet" href="CSS\Buscador.css">


</head>
<body>
<div id="general">
<div id="lateral">
<a href="login.php"><img src="imagenes\logueo.png" width="70" height="60" ><p align="center">Iniciar Sesion</p></a>
<br><br>
<a href="https://web.whatsapp.com/"><img src="imagenes\wta.png" width="70" height="60"><p align="center">7000-3456</p></a>
<br><br>
<a href="https://www.facebook.com/Clinicaveterinariachalchuapa-111191790599220/?modal=admin_todo_tour"><img src="imagenes\face.png" width="70" height="60"><p align="center">ClinicaVeterinaria</p><p align="center">Chalchuapa</p></a>
<br><br>
<a href="https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F%3Ftab%3Drm%26ogbl&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin"><img src="imagenes\gm.png" width="70" height="60"><p align="center">ClinicaVeterinaria</p><p align="center">veteriachalchuapa@gmail.com</p></a>


</div>
<div id="banner">
</div>
<div id="header">
<header>
<nav>
	<?php
		session_start();
		if(isset($_SESSION["usuario"])){
			if($_SESSION["usuario"]["nivel"]=='administrador'){
				echo "<ul>";
				echo "<li> <a href=>Acciones</a>";
				echo "<ul>";
				echo "<li> <a href=pedidos.php>Gestor de ventas</a></li>";
				echo "<li> <a href=reservacion.php>Reservacion de citas</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href=>Mantenimientos</a>";
				echo "<ul>";
				echo "<li> <a href=productos.php>Productos</a></li>";
				echo "<li> <a href=categorias.php>Categorias</a></li>";
				echo "<li> <a href=proveedores.php>Proveedores</a></li>";
				echo "<li> <a href=usuarios.php>Usuarios</a></li>";
				echo "<li> <a href=cliente.php>clientes</a></li>";
				echo "<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href=>Reportes</a>";
				echo "<ul>";
				echo "<li> <a href=inventario.php>Reporte de Inventario</a></li>";
				echo "<li> <a href=citas.php>Citas Agendadas</a></li>";
				echo "<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>";
				/*echo "<li>";
					echo "<div id=search>";
					echo "<form>";
					echo "<fieldset>";
					echo "<input type=search placeholder=  Buscar...>";
					echo "<button type=submit>";
					echo "<i class='fa fa-search'></i>";
					echo "</button>";
					echo "</fieldset>";	
					echo "</form>";
					echo "</div>";
				echo "</li>";*/
				echo "</ul>";
			}else{

				echo "<ul>";
				echo "<li> <a href=>Acciones</a>";
				echo "<ul>";
				echo "<li> <a href=pedidos.php>Gestor de ventas</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href=>Mantenimientos</a>";
				echo "<ul>";
				echo "<li> <a href=productos.php>Productos</a></li>";
				echo "<li> <a href=categorias.php>Categorias</a></li>";
				echo "<li> <a href=proveedores.php>Proveedores</a></li>";
				echo "<li> <a href=cliente.php>clientes</a></li>";
				echo "<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href=>Por usuario</a>";
				echo "<ul>";
				echo "<li> <a href=actualizarperfil.php>Actualizar Perfil</a></li>";
				echo "<li> <a href=reservacion.php>Reservacion de citas</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href=>Reportes</a>";
				echo "<ul>";
				echo "<li> <a href=inventario.php>Reporte de Inventario</a></li>";
				echo "<li> <a href=citas.php>Citas Agendadas</a></li>";
				echo "<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>";
				echo "</ul>";
				echo "</li>";
				echo "<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>";				
				echo "</ul>";
			}
		}else{

			echo "<ul>";
			echo "<li> <a href=>Servicios</a>";
			echo "<ul>";
			echo "<li> <a href=vacunacion.php>Vacunacion</a></li>";
			echo "</ul>";
			echo "</li>";
			echo "<li> <a href=>Productos</a>";
			echo "<ul>";
			echo "<li> <a href=alimentos.php>Alimentos</a></li>";
			echo "<li> <a href=higiene.php>Higiene</a></li>";
			echo "<li> <a href=medicamentos.php>Medicamentos</a></li>";
			echo "</ul>";
			echo "</li>";
			echo "<li> <a href=>Quines somos</a>";
			echo "<ul>";
			echo "<li> <a href=mision.php>Mision</a></li>";
			echo "<li> <a href=vision.php>Vision</a></li>";
			echo "</ul>";
			echo "</li>";

			echo "<li> <a href=>Acciones</a>";
			echo "<ul>";
			echo "<li> <a href=reservacion.php>Reservacion de citas</a></li>";
			echo "</ul>";
			echo "</li>";	
			echo "<li> <a href=login.php>Login</a></li>";			
			echo "</ul>";

		}
	?>
</nav>
</header>
	
</div>
<div id="contenido">
<br><br>
<div id="imagenes">

<ul>
<li><img src="imagenes\perro.jpg">
<li><img src="imagenes\xc.jpg">
<li><img src="imagenes\kl.jpg">
<li><img src="imagenes\bv.jpeg">
</ul>
</div>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3871.6195622019827!2d-89.68035268572383!3d13.981235990199258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8f62eb1483b862b9%3A0xba2c68c63821c151!2sClinica%20Veterinaria%20Chalchuapa!5e0!3m2!1ses!2ssv!4v1589985676513!5m2!1ses!2ssv" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

</div>
<div id="footer">
<p><h2>Clinica Veterinaria Chalchuapa| ©2020 Todos los derechos reservados | Políticas de privacidad</h2></p>
</div>
</div>
</body>
</html>