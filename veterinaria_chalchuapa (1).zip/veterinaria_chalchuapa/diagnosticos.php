
<style>
	.ini{
		width: 25%;
		margin: 0% auto;
		background: black;
		padding: 10px;
		
	}
	table{
		color: white;
	}
	.tr{
		margin:0 auto;
	}
	.res{
		width: 100%;
		margin: 0px auto;
		background: silver;
		border-radius: 0.5em;
		padding: 2% 0%;
	}
	.all{
		background: gray;
		height: 100%;
		padding: 5% 0%;
	}
	.tabl{
		color: white;
		background: black;
		border-color: white;
	}

</style>

<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>
<div class=all>
<?php
include "metodos.php";
$obj=new Metodos();

$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli($servername,$username,$password,$dbname);
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}

if(isset($_POST["enviar"])){
	echo "<div class=ini>";
	echo "<form method=post>";
	if($_POST["orden"]=="Nombre de Propietario"){
			echo "<table align=center class=tabl>";
			echo "<tr><td>Nombre del dueño</td><td><input type=text name=nombre required></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok value=buscar></td></tr>";
		echo "</table>";
	}elseif($_POST["orden"]=="Tipo de Mascota"){
			echo "<table align=center>";
			echo "<tr><td>Tipo de Mascota</td><td><select name=mascota>";
				echo "<option>Canino</option>";
				echo "<option>Felino</option>";
				echo "<option>Aves</option>";
				echo "<option>Peces</option>";
			echo "</select></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok1 value=buscar></td></tr>";
			echo "</table>";
	}elseif($_POST["orden"]=="Fecha de siguiente control"){
			echo "<table align=center>";
			echo "<tr><td>Fecha de cita</td><td><input type=date required name=fecha></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok2 value=buscar></td></tr>";
			echo "</table>";
	}elseif($_POST["orden"]=="Sexo de mascota"){
			echo "<table align=center>";
			echo "<tr><td colspan=2 align=center><label for=>Sexo</label></td></tr>";
			echo "<tr><td><input type=radio name=sexo value=Baron checked>Baron</td><td><input type=radio name=sexo value=Hembra>Hembra</td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok3 value=buscar></td></tr>";
			echo "</table>";
	}elseif($_POST["orden"]=="Estado"){
			echo "<table align=center>";
			echo "<tr><td colspan=2 align=center>Estado del paciente</td></tr>";
			echo "<tr><td><input type=radio name=estado value=Activo checked>Activo</td><td><input type=radio name=estado value='Dado de Alta'>Dado de Alta</td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok4 value=buscar></td></tr>";
			echo "</table>";
	}
	echo "</form>";
	echo "</div>";
}elseif(isset($_POST["ok"])){
	echo "<div class=res>";
	$nombre=$_POST["nombre"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,diagnostico,tratamiento,siguiente_cita,diagnosticos.`estado` FROM diagnosticos INNER JOIN citas ON diagnosticos.`id_cita`=citas.`id_cita` WHERE nombre_propietario LIKE '%$nombre%' OR apellido_propietario LIKE '%$nombre%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tr><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
}elseif(isset($_POST["ok1"])){
	echo "<div class=res>";
	$tipo=$_POST["mascota"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,diagnostico,tratamiento,siguiente_cita,diagnosticos.`estado` FROM diagnosticos INNER JOIN citas ON diagnosticos.`id_cita`=citas.`id_cita` WHERE tipo_mascota LIKE '%$tipo%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tr><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok2"])){
	echo "<div class=res>";
	$fecha=$_POST["fecha"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,diagnostico,tratamiento,siguiente_cita,diagnosticos.`estado` FROM diagnosticos INNER JOIN citas ON diagnosticos.`id_cita`=citas.`id_cita` WHERE siguiente_cita LIKE '%$fecha%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tr><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok3"])){
	echo "<div class=res>";
	$sexo=$_POST["sexo"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,diagnostico,tratamiento,siguiente_cita,diagnosticos.`estado` FROM diagnosticos INNER JOIN citas ON diagnosticos.`id_cita`=citas.`id_cita` WHERE sexo_mascota LIKE '%$sexo%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tr><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok4"])){
	echo "<div class=res>";
	$estado=$_POST["estado"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,diagnostico,tratamiento,siguiente_cita,diagnosticos.`estado` FROM diagnosticos INNER JOIN citas ON diagnosticos.`id_cita`=citas.`id_cita` WHERE diagnosticos.`estado` LIKE '%$estado%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tr><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}/*elseif(isset($_POST["eliminar"])){

	$sql="UPDATE citas SET estado='NULL' WHERE estado LIKE '%Realizada%'";
	$obj->actualizar($sql);
	header("Location:citas.php");
}*/else{
	echo "<div class=ini>";
	echo "<form method=post>";
		echo "<table align=center class=tbl>";
			echo "<tr><td>Buscar Por</td><td><select name=orden>";
				echo "<option>Nombre de Propietario</option>";
				echo "<option>Tipo de Mascota</option>";
				echo "<option>Fecha de siguiente control</option>";
				echo "<option>Sexo de mascota</option>";
			echo "<option>Estado</option>";
			echo "</select></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=enviar value='    Ir    ''></td></tr>";
		echo "</table>";
	echo "</form>";
	echo "</div>";
	echo "<div class=res>";
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,diagnostico,tratamiento,siguiente_cita FROM diagnosticos INNER JOIN citas ON diagnosticos.`id_cita`=citas.`id_cita`";
	echo $obj->mostrar($sql);
	echo "</div>";

	/*echo "<br><br><form method=post>";
		echo "<table align=center>";
			echo "<tr><td><input type=submit name=eliminar value='limpiar realizadas'></td></tr>";
		echo "</table>";
	echo "</form>";*/
}
?>
</div>
