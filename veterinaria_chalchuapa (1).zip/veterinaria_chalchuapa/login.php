<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">

	<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS\login.css">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">



</head>
<?php
	session_start();
	if(isset($_SESSION["usuario"])){
		if($_SESSION["usuario"]["nivel"]=='administrador'||$_SESSION["usuario"]["nivel"]=='user'){
			header("Location:index.php");
		}
	}
?>

<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=clinica.php>Clinica</a></li>
<li> <a href=peluqueria.php>Peluqueria</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>							
</ul>
</nav>
</header>	
</div>
<div class="modal-dialog text-center">
<div class="col-sm-8 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="imagenes\logueo.png">
</div>
<form action="acceso.php" class="col-12" id="form" method=post>
<div class="form-group" id="user-group">
<input type="text" name=usuario class="form-control" placeholder="Nombre de usuario">
</div>
<div class="form-group"id="contraseña-group">
<input type="password" name=contra class="form-control" placeholder="Contraseña">
</div>
<button type="submit" class="btn btn-primary" name=enviar><i class="fas fa-sing-in-alt"></i>/  Ingresar</button>
</form>

</div>
</div>
</div>
</body>
</html>


