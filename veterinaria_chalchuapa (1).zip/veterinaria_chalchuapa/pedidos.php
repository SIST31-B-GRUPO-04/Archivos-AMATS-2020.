<?php
	include "metodos.php";
	$obj=new Metodos();
	session_start();
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$conn=new mysqli($servername,$username,$password,$dbname);
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">

	<link rel="stylesheet" href="CSS\estilo.css">
<script type="text/javascript">
	 function habilitar(){
	 	var btn=document.getElementsByTagName('enviar');
	 	btn.disabled=true;
	 }
</script>
<style>
	.r{
		background: white;
		width: 100px;
	}

	.r td{
		max-width: 150px;
		max-height: 100px;
		writing-mode: sideways-rl;
	}
	.wrap{
		width: 100px;
		white-space: pre-wrap;
		white-space: -moz-pre-wrap;
		white-space: -pre-wrap;
		white-space: -o-pre-wrap;
		word-wrap: break-word;
		height: auto;
		border:1px solid red;
	}
</style>
</head>
<body>

	
<div class=gral>
	<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>
	<section class=contenido>
		<h1 align="center" class="hh">Sistema de ventas</h2>
		<div class=cabecera>
			
		</div>
		<form class=frm method="post" name=frm>
			<div class=tabla>
			Seleccione Dui<select name="dui"><?php echo $obj->cargarselect("clientes");?></select>
				<br><br>Producto<select name=prod id=pr>
					<?php
						echo $obj->cargarselect("productos");
					?>
				</select><td align="center"><br><br>Cantidad
				<br><input type=number name=cantidad min=1 max=50>
				
				<input type="submit" class=boton  name="enviar" value="Agregar a Pedido"><br><br><input type=submit class=boton1 name=terminar value="finalizar venta">
		</div>
		<div class=arr>
			<?php

					$fecha=date("Y")."-".date("m")."-".date("d");
					$tot=0;
				
				/*echo "<form method=post name=frmrep>";
				echo "<input type=text name=id id=j>";
				echo $obj->mostrarycargar("","pedidos");
				
				echo "</form>";*/
				echo "<div class=tabla>";
				echo "<table class=r border=1><thead><tr><th>Producto</th><th>Cantidad</th><th>preciou</th><th>subtotal</th></tr></thead>";
				$tbl="";
				if (isset($_POST["enviar"])) {
					/*if (isset($_COOKIE["pedido"])) {
						setcookie("pedido",$_COOKIE["pedido"],time()+172800);
					}else{
						setcookie("pedido",1,time()+172800);
						$ped="INSERT INTO pedidos VALUES('',0,'$fecha')";
					if($conn->query($ped)===TRUE){
					}else{
						echo "error: ".$ped."<br>".$conn->error;
					}
					}
					$id_ped=$_COOKIE['pedido'];*/
					
					$nombre=$_POST["prod"];
					$cant=$_POST["cantidad"];
					if (isset($_SESSION["dui"])){
					$_SESSION["dui"]=$_SESSION["dui"];
				}else{
					$_SESSION["dui"]=$_POST["dui"];
				}
				$res=$conn->query("SELECT precio,existencia FROM productos WHERE nombre_producto='$nombre'");

					//$conn->close();
					while($fila=mysqli_fetch_row($res)){
						$tbl.="<tr><td><div class=wrap>$nombre</div></td><td>$cant</td><td>\$$fila[0]</td><td>\$".($fila[0]*$cant)."</td></tr>";
						if (isset($_SESSION["tbl"])) {
							$_SESSION["tbl"].=$tbl;
						}else{
							$_SESSION["tbl"]=$tbl;
						}
						$prod=$fila[0];
						$tot=($prod*$cant);
						$existencia=$fila[1];
					}
					if($cant>$existencia){
						$tot=$tot-($prod*$cant);
						echo "no hay suficientes productos en existencia";
					}else{

						if (isset($_SESSION["tot"])) {
							$_SESSION["tot"]+=$tot;
						}else{
							$_SESSION["tot"]=$tot;
						}


					$sql="UPDATE productos SET existencia=".($existencia-$cant)." WHERE nombre_producto='$nombre'";
					$obj->actualizar($sql);


					$dui=$_SESSION['dui'];
					

				$res=$conn->query("SELECT id_pedido FROM pedidos");
					
					while($fila=mysqli_fetch_row($res)){
						$cont=count($fila);
						$_SESSION["id"]=$fila[$cont-1];
					}
					//$conn->close();
					$pedido=$_SESSION["id"];
					$sql="INSERT INTO ventas
					 VALUES ('',$pedido,(SELECT id_producto from productos WHERE nombre_producto='$nombre'),'$dui',$cant,".round($tot,2).",'$fecha')";
					$obj->insertar($sql);
					echo $_SESSION["tbl"];
					echo "<tr><td colspan=3>Total</td><td>\$".$_SESSION["tot"]."</td></tr>";
					echo "</div>";}
					//header("Location:reporte.php"); 
				}elseif (isset($_POST["terminar"])) {
					$pedido=$_SESSION["id"];
					$totalo=$_SESSION["tot"];
					$sql="UPDATE pedidos SET total=$totalo,fecha=$fecha WHERE id_pedido=$pedido";
					$obj->actualizar($sql);
					$sql="INSERT INTO pedidos
					 VALUES ('',0,'$fecha')";
					$obj->insertar($sql);
					//setcookie("pedido",$_COOKIE["pedido"]+1,time()+172800);
					unset($_SESSION["tbl"],$_SESSION["tot"]);
					header("Location:factura.php");
				}/*elseif (isset($_POST["limpiar"])) {
					session_destroy();
				}*/
			?>
		</div>
		</form>
	</section>
</div>
</body>