
<?php
	session_start();
	include "metodos.php";
	
?>
<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript">
		function cargar(nombre,apell,tel,mail,usuario,clave){
			document.frmact.nombre.value=nombre;
			document.frmact.ape.value=apell;
			document.frmact.tel.value=tel;
			document.frmact.mail.value=mail;
			document.frmact.user.value=usuario;
			document.frmact.pass.value=clave;
			
		}
	</script>
<meta charset="utf-8">
	<!-- JQUERY -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!--FRAMEWORK BOOTSTRAP para el estilo de la pagina-->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<scriptsrc="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js></script>


<!-- Nuestro css-->
<link rel="stylesheet" type="text/css" href="CSS\login.css">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">
	

</head>

<body>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Por usuario</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=citas.php>Citas Agendadas</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>"			
</ul>
</nav>
</header>	
</div>
<?php
	if(isset($_SESSION["usuario"])){
		if($_SESSION["usuario"]["nivel"]=='administrador'|| $_SESSION["usuario"]["nivel"]=='user'){
			echo "Bienvenido ".$_SESSION["usuario"]["nombre"]."(".$_SESSION["usuario"]["nivel"].")";
			echo "<a href='acceso.php?cerrar=true'>Cerrar Sesion</a>";
		}else{
			header("Location:login.php");
		}
	}else{
		header("Location:login.php");
		}
?>
<div class="modal-dialog text-center">
<div class="col-sm-8 main-section">
<div class="modal-content">
<div class="col-12 user-img">
<img src="imagenes\logueo.png">
<?php
	$obj=new Metodos();
	echo $obj->cargar("usuarios");
?>
</div>
<form class="col-12" method=post name=frmact>

<div class="form-group" id="user-group">
Nombre:<input type="text" class="form-control" name=nombre>
</div>

<div class="form-group" id="apellido-group">
Apellido:<input type="text" class="form-control" name=ape>
</div>

<div class="form-group" id="tel-group">
Tel:<input type="tel" class="form-control" name=tel>
</div>

<div class="form-group" id="e-mail-group">
E-mail<input type="email" class="form-control" name=mail>
</div>

<div class="form-group" id="user-group">
Usuario:<input type="text" class="form-control" name=user>
</div>

<div class="form-group"id="contraseña-group">
Contraseña:<input type="password" class="form-control" name=pass>
</div>
<button type="submit" class="btn btn-primary" name=enviar><i class="fas fa-sing-in-alt"></i>/  Ingresar</button>
</form>
<div class="col-12 forgot">
<a href="#">Recordar contraseña ?</a>
</div>
</div>
</div>
</div>
</body>
</html>

<?php
	
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="clinica";
	$tipo=$_SESSION["usuario"]["nivel"];
	$conn=new mysqli($servername,$username,$password,$dbname);
	if ($conn->connect_error) {
		die("connection failed: ".$conn->connect_error);
	}
	if(isset($_POST["enviar"])){
			$nombre=$_POST["nombre"];
			$apell=$_POST["ape"];
			$tel=$_POST["tel"];
			$mail=$_POST["mail"];
			$usuario=$_POST["user"];
			$contra=$_POST["pass"];
			$sess=$_SESSION["usuario"]["nivel"];
			$sql="UPDATE usuarios SET nombre_usuario='$nombre',ap_usuario='$apell',tel='$tel',email='$mail',alias='$usuario',clave='$contra' WHERE tipo='$sess'";
			$obj->actualizar($sql);
			if ($obj==true) {
				echo $obj->mostrar("SELECT * FROM usuarios");
			}else{
				echo "error";
			}
	}
?>