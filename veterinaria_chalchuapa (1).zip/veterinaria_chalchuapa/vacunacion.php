<!DOCTYPE html>
<html lang="es">
<head>
<title>Vacunacion</title>
<a href="ejemplo.html">Inicio</a></li>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css\estilo.css">
<link rel="stylesheet" type="text/css" href="css\tienda.css">
<link href="https://fonts.googleapis.com/css?famaly=Lato" rel="stylesheet">
</head>
<body>
<div id="general">
<div id="banner">
</div>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=vacunacion.php>Vacunacion</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>
</div>
<br><br><br>
<div id="contenedor">

<section class="Productos">
<br>
<h1 align="center"> Servicio de vacunacion .</h1>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="imagenes\p1.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$11.00</h2>
<br>
<p>Control de parasitos inyectado</p>
<p>Canino. (20ml)</p>

</section>
</section>

<section class="productos-item">
<img src="imagenes\p2.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$11.00</h2>
<p>Nanormen Suspencion Oral</p>
<p>Antiparasitorio Nematicida. (20ml)</p>
</section>
</section>

<section class="productos-item">
<img src="imagenes\p3.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$9.00</h2>
<p>Basken Doble 40</p>
<p>Antiparasitorio de Espectro Total.(10tbls)</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="imagenes\p4.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$9.00</h2>
<p>Basken Plus Antiparasitorio</p>
<p> de Espectro Total. (25tbls)</p>
</section>
</section>

<section class="productos-item">
<img src="imagenes\p5.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$11.00</h2>
<p>Rabies Vaccine.</p>
<p>Vacuna contra la rabia.(3TF)</p>
</section>
</section>

<section class="productos-item">
<img src="imagenes\p6.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$11.00</h2>
<p>Bronchicine</p>
<p>Bacterin(10ml)</p>
</section>
</section>
</div>
</section>


<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="imagenes\p7.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$12.00</h2>
<p>Virbac</p>
<p>Leucogen(1 dosis)</p>
</section>
</section>

<section class="productos-item">
<img src="imagenes\p8.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$20.00</h2>
<p>Vacuna contra coronavirus</p>
<p>canino.(1ml)</p>
</section>
</section>

<section class="productos-item">
<img src="imagenes\p9.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$12.00</h2>
<p>Vacuna Parvovirus</p>
<p>Canino.(1ml)</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="imagenes\p10.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$25.00</h2>
<p>Canigen</p>
<p>MHA2ppi</p>
</section>
</section>

<section class="productos-item">
<img src="imagenes\p11.jpg"alt="" class="productos-img">
<section class="productos-info">
<h2>$16.00</h2>
<p>Vacuna Triple</p>
<p>Felina(1ml)</p>
</section>
</section>

</div>
</section>
</body>
</div>
</div>
</body>
</html>