CREATE DATABASE clinica;
USE clinica;
CREATE TABLE usuarios(
id_usuario INT(9) NOT NULL AUTO_INCREMENT,
nombre_usuario CHAR(50) NOT NULL,
ap_usuario CHAR(50) NOT NULL,
tipo CHAR(30) NULL,
tel CHAR(10) NULL,
email CHAR(50) NULL,
estado CHAR(30) NULL,
alias CHAR(30) NOT NULL,
clave CHAR(50) NOT NULL,
PRIMARY KEY(id_usuario)
);

INSERT INTO usuarios(id_usuario,nombre_usuario,ap_usuario,tipo,tel,email,estado,alias,clave) VALUES
('','---','---','administrador','---','s@.algo','activo','admin','0000'),
('','---','---','user','---','s@.algo','activo','user','1111');

CREATE TABLE clientes (
  id_cliente CHAR(11) NOT NULL,
  nombre_cliente CHAR(50) NOT NULL,
  apellido_client CHAR(50) NOT NULL,
  tel CHAR(10) DEFAULT NULL,
  nombre_usuario VARCHAR(100) NOT NULL,
  clave CHAR(30) DEFAULT NULL,
  PRIMARY KEY (id_cliente)
)

INSERT INTO clientes (id_cliente, nombre_cliente, Apellido_client, tel) VALUES
('01234567-0', 'Willian','Juarez','7788-1214'),
('04765432-1', 'Marta','Gonzales','7898-2154'),
('04565632-6', 'Elena','HernÃ¡ndez','2132-8754'),
('03765437-8', 'Julio','Maldonado','2014-4517'),
('05765758-3', 'Helen','montez','7895-8412'),
('04885432-0', 'Juan','Ramirez','7021-5488'),
('06787989-8', 'Jorge','Maldonado','2418-4587'),
('02784589-6', 'Marta','Cabrera','2018-5478'),
('02987987-9', 'Julio','Estrada','2512-1314'),
('02147483-6', 'Roberto','Morazan','2408-1214');

CREATE TABLE proveedores(
id_proveedor INT NOT NULL AUTO_INCREMENT,
nombre_proveedor VARCHAR(100) NOT NULL,
tel CHAR(10) DEFAULT NULL,
email CHAR(50) DEFAULT NULL,
direccion VARCHAR(100) NOT NULL,
PRIMARY KEY(id_proveedor)
);


INSERT INTO proveedores (id_proveedor,nombre_proveedor,tel,email,direccion) VALUES
('','prov1','54848','gerg','erg'),
('','prov2','51646','ergf','etget');

CREATE TABLE categorias(
id_categoria INT NOT NULL AUTO_INCREMENT,
nombre_categoria VARCHAR(100) NOT NULL,
descripcion  VARCHAR(100) NULL,
PRIMARY KEY(id_categoria)
);

INSERT INTO categorias (id_categoria,nombre_categoria,descripcion) VALUES
('','Alimentos','desc1'),
('','Higiene','desc2'),
('','Medicamentos','desc2');

CREATE TABLE productos(
id_producto INT NOT NULL AUTO_INCREMENT,
id_categoria INT NOT NULL,
id_proveedor INT NOT NULL,
nombre_producto VARCHAR(100) NOT NULL,
descripcion VARCHAR(100) NULL,
precio DOUBLE(5,2) NOT NULL,
existencia INT(9) NULL,
INDEX(id_categoria),
INDEX(id_proveedor),
PRIMARY KEY (id_producto),
 KEY FK_cat (id_categoria),
CONSTRAINT FK_cat FOREIGN KEY (id_categoria) REFERENCES categorias (id_categoria),
 KEY FK_prov (id_proveedor),
CONSTRAINT FK_prov FOREIGN KEY (id_proveedor) REFERENCES proveedores(id_proveedor)
);

INSERT INTO productos (id_producto,id_categoria,id_proveedor,nombre_producto,descripcion,precio,existencia) VALUES
('',1,2,'Royal_canin_lata–Starter_mousse.','----',3.67,'100'),
('',1,2,'Royal_canin_lata-Renal_(410gr).','----',4.97,'100'),
('',1,2,'Royal_canin_Hepatic_(420gr).','----',8.97,'100'),
('',1,2,'Pro_plan_lata–Adulto_Sensitive','----',4.50,'100'),
('',1,2,'Pro_plan_lata–Adulto_7+_Beef','----',4.50,'100'),
('',1,2,'Nupec-cachorro_raza_pequeña_(8kg)','----',58.00,'100'),
('',1,1,'Nupec–Cachorro_raza_grande(2kg))','----',15.5,'100'),
('',1,1,'Royal_canin–Hypoallergenic(2kg)','----',33.9,'100'),
('',1,1,'Royal_canin–Stater_mother','----',33.9,'100'),
('',1,1,'Nupec-Adulto_raza_grande_(2kg)','----',13.5,'100'),
('',2,1,'Shampoo_Mv.Desma_Antiricotico','----',15.0,'100'),
('',2,1,'Shampoo_Mv.Desma_Antipruriginoso','----',20.0,'100'),
('',2,1,'Shampoo_Mv.Desma_Piel_sensible_16_onz','----',12.0,'100'),
('',2,1,'Shampoo_Mv._Desma_Ectoparasiticido','----',15.0,'100'),
('',2,1,'Shampoo_Avena_y_miel_Collie_16_onz','----',6.50,'100'),
('',2,1,'Shampoo_Acondicionador,Avena_y_miel','----',6.50,'100'),
('',2,1,'Shampoo_para_Cachorro_Collie_16_onz','----',6.50,'100'),
('',3,2,'Ecthol–collar_antipulgas_para_gatos_40cm','----',16.50,'100'),
('',3,2,'Ecthol–collar_antipulgas_y_garrapatas_40_cm','----',18.00,'100'),
('',3,2,'Ecthol–collar_antipulgas_y_garrapatas_63_cm','----',20.00,'100'),
('',3,2,'Calciphos_60_Tabletas','----',12.50,'100'),
('',3,2,'Shed_Relief_16_onz','----',20.00,'100'),
('',3,2,'Hemovit–B12_2_onz','----',20.00,'100'),
('',3,2,'Supercal–D3_60_ml','----',7.50,'100'),
('',3,2,'Hemofer–B12_60_tabletas','----',20.00,'100');


CREATE TABLE citas(
id_cita INT NOT NULL AUTO_INCREMENT,
nombre_propietario CHAR(50) NOT NULL,
apellido_propietario CHAR(50) NOT NULL,
tel CHAR(10) NULL,
nombre_mascota  VARCHAR(100) NOT NULL,
sexo_mascota  CHAR(10) NOT NULL,
tipo_mascota  CHAR(50) NOT NULL,
edad_mascota  CHAR(15) NOT NULL,
fecha CHAR(30) NOT NULL,
hora CHAR(12) NOT NULL,
dui CHAR(10) NULL,
estado CHAR(10) NOT NULL,
PRIMARY KEY(id_cita)
);

CREATE TABLE diagnosticos (
id_diagnostico INT NOT NULL AUTO_INCREMENT,
id_cita INT NULL,
id_cliente CHAR(11) NULL,
diagnostico VARCHAR(500) NOT NULL,
tratamiento VARCHAR(500) NOT NULL,
siguiente_cita CHAR(30) NULL,
estado CHAR(30) NULL,
PRIMARY KEY(id_diagnostico),
KEY FKcita(id_cita),
CONSTRAINT FKcita FOREIGN KEY(id_cita) REFERENCES citas(id_cita),
KEY FKclient(id_cliente),
  CONSTRAINT FKclient FOREIGN KEY(id_cliente) REFERENCES clientes(id_cliente)
)

CREATE TABLE pedidos (
  id_pedido INT NOT NULL AUTO_INCREMENT,
  total DOUBLE(6,2),
  fecha CHAR(30) NULL,
  PRIMARY KEY(id_pedido)
)
INSERT INTO pedidos VALUES('',0,'---')
SELECT * FROM productos
CREATE TABLE ventas (
  id_venta INT(11) NOT NULL AUTO_INCREMENT,
  id_pedido INT NULL,
  id_producto INT(11) DEFAULT NULL,
  id_cliente CHAR(11) NULL,
  cantidad INT(10) DEFAULT NULL,
  subtotal DECIMAL(12,2) NULL,
  fecha CHAR(30) NULL,
  PRIMARY KEY (id_venta),
  KEY FK_prod (id_producto),
  CONSTRAINT FK_prod FOREIGN KEY (id_producto) REFERENCES productos (id_producto),
  KEY FKcli(id_cliente),
  CONSTRAINT FKcli FOREIGN KEY(id_cliente) REFERENCES clientes(id_cliente),
   KEY FKped(id_pedido),
  CONSTRAINT FKped FOREIGN KEY(id_pedido) REFERENCES pedidos(id_pedido)
)
DELETE FROM productos WHERE id_producto=26




