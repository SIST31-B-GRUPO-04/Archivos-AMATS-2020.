<!DOCTYPE html>
<html lang="es">
<head>
<title>Medicamentos</title>
<a href="ejemplo.html">Inicio</a></li>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="CSS\estilo.css">
<link rel="stylesheet" type="text/css" href="CSS\tienda.css">
<link href="https://fonts.googleapis.com/css?famaly=Lato" rel="stylesheet">

</head>
<body>
<div id="general">

<div id="banner">
</div>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Servicios</a>
<ul>
<li> <a href=clinica.php>Clinica</a></li>
<li> <a href=peluqueria.php>Peluqueria</a></li>
</ul>
</li>
<li> <a href=>Productos</a>
<ul>
<li> <a href=alimentos.php>Alimentos</a></li>
<li> <a href=higiene.php>Higiene</a></li>
<li> <a href=medicamentos.php>Medicamentos</a></li>
</ul>
</li>
<li> <a href=>Quines somos</a>
<ul>
<li> <a href=mision.php>Mision</a></li>
<li> <a href=vision.php>Vision</a></li>
</ul>
</li>

<li> <a href=>Acciones</a>
<ul>
<li> <a href=reservacion.php>Reservacion de citas</a></li>
</ul>
</li>
<li> <a href=login.php>Login</a></li>							
</ul>
</nav>
</header>
</div>
<br><br><br>

<div id="contenedor">
<section class="Productos">
<br>
<h1 align="center">Medicamentos</h1>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\m1.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$16.50</h2>
<br>
<p>Ecthol–collar antipulgas </p>
<p> para gatos (40) cm</p>

</section>
</section>

<section class="productos-item">
<img src="Imagenes\m2.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$16.00</h2>
<p>Ecthol–collar antipulgas  </p>
<p>y garrapatas (40) cm razas pequeñas</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m3.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$20.00</h2>
<p>Ecthol–collar antipulgas  </p>
<p>y garrapatas (63) cm razas Grandes</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\m4.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$12.50</h2>
<p>Calciphos  </p>
<p>(60)  Tabletas </p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m5.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$20.00</h2>
<p>Shed Relief  </p>
<p>Collie (16) onz</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m6.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$10.50</h2>
<p>Hemovit – B12 </p>
<p> (16)onz</p>
</section>
</section>
</div>
</section>


<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\m7.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$4.50</h2>
<p> Super cal – D3   </p>
<p>(60 ) ml</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m8.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$20.00</h2>
<p>Hemofer – B12   </p>
<p> (60) tabletas</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m9.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$24.00</h2>
<p>Hepato Can    </p>
<p> (60) tabletas</p>
</section>
</section>
</div>
</section>

<div id="contenedor">
<section class="Productos">
<br>

<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\m10.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$23.00</h2>
<p>Artri – Tabs  </p>
<p> (60) tabletas</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m11.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$14.00</h2>
<p>Vitamina Petavit   </p>
<p> (60) tabletas</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m12.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$7.50</h2>
<p>ADO QUATRO Protector de   </p>
<p> las almohadillas </p>
</section>
</section>
</div>
</section>
</section>
</section>
<div id="contenedor">
<section class="Productos">
<br>
<br><br><br>
<div class="productos-container">
<section class="productos-item">
<img src="Imagenes\m13.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$13.00</h2>
<p>ENTEROFILUS </p>
<p>(12X10) ML</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m14.png"alt="" class="productos-img">
<section class="productos-info">
<h2>$20.00</h2>
<p>FLUNIXIN </p>
<p>(100)ML</p>
</section>
</section>

<section class="productos-item">
<img src="Imagenes\m15.JPG"alt="" class="productos-img">
<section class="productos-info">
<h2>$3.50</h2>
<p>LACTATO RINGER   </p>
<p>VET BRAUN(500)  ML</p>
</section>
</section>
</div>
</section>


</body>
</div>
</div>
</body>

</html>