
<style>
	.ini{
		width: 20%;
		margin: 0% 40%;
		background: black;
		padding: 10px;
		
	}
	.tree{
		margin:auto;
	}
	table{
		color: white;
	}
	.res{
		width: 90%;
		margin: 0px auto;
		background: silver;
		border-radius: 0.5em;
		padding: 2% 0%;
	}
	.all{
		background: gray;
		height: 100%;
		padding: 5% 0%;
	}
	.tabl{
		color: white;
		background: black;
		border-color: white;
	}

</style>
<div id="header">
<header>
<nav>
<ul>
<li> <a href=index.php>Inicio</a></li>
<li> <a href=>Acciones</a>
<ul>
<li> <a href=pedidos.php>Gestor de ventas</a></li>
</ul>
</li>
<li> <a href=>Mantenimientos</a>
<ul>
<li> <a href=productos.php>Productos</a></li>
<li> <a href=categorias.php>Categorias</a></li>
<li> <a href=proveedores.php>Proveedores</a></li>
<li> <a href=usuarios.php>Usuarios</a></li>
<li> <a href=cliente.php>clientes</a></li>
<li> <a href=ingresodediagnosticos.php>diagnosticos</a></li>
</ul>
</li>
<li> <a href=>Reportes</a>
<ul>
<li> <a href=inventario.php>Reporte de Inventario</a></li>
<li> <a href=diagnosticos.php>Historial de Diagnosticos</a></li>
</ul>
</li>
<li> <a href='acceso.php?cerrar=true'>Cerrar Session</a></li>
</ul>
</nav>
</header>
</div>

<div class=all>
<?php
include "metodos.php";
$obj=new Metodos();



if(isset($_POST["enviar"])){
	echo "<div class=ini>";
	echo "<form method=post>";
	if($_POST["orden"]=="Nombre de Propietario"){
			echo "<table align=center class=tabl>";
			echo "<tr><td>Nombre del dueño</td><td><input type=text name=nombre required></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok value=buscar></td></tr>";
		echo "</table>";
	}elseif($_POST["orden"]=="Tipo de Mascota"){
			echo "<table align=center>";
			echo "<tr><td>Tipo de Mascota</td><td><select name=mascota>";
				echo "<option>Canino</option>";
				echo "<option>Felino</option>";
				echo "<option>Aves</option>";
				echo "<option>Peces</option>";
			echo "</select></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok1 value=buscar></td></tr>";
		echo "</table>";
	}elseif($_POST["orden"]=="Fecha"){
			echo "<table align=center>";
			echo "<tr><td>Fecha de cita</td><td><input type=date required name=fecha></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok2 value=buscar></td></tr>";
		echo "</table>";
	}elseif($_POST["orden"]=="Hora"){
			echo "<table align=center>";
			echo "<tr><td>Hora de cita</td><td><input type=time required name=hora></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok3 value=buscar></td></tr>";
		echo "</table>";
	}elseif($_POST["orden"]=="Estado"){
			echo "<table align=center>";
			echo "<tr><td>Estado de cita</td><td><select name=estado>
				<option>pendiente</option>
				<option>Realizada</option>
			</select></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=ok4 value=buscar></td></tr>";
		echo "</table>";
	}
	echo "</form>";
	echo "</div>";

}elseif(isset($_POST["ok"])){
	echo "<div class=res>";
	$nombre=$_POST["nombre"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,fecha,hora,dui,estado FROM citas WHERE nombre_propietario LIKE '%$nombre%' OR apellido_propietario LIKE '%$nombre%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tree><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok1"])){
	echo "<div class=res>";
	$tipo=$_POST["mascota"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,fecha,hora,dui,estado FROM citas WHERE tipo_mascota LIKE '%$tipo%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tree><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok2"])){
	echo "<div class=res>";
	$fecha=$_POST["fecha"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,fecha,hora,dui,estado FROM citas WHERE fecha LIKE '%$fecha%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tree><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok3"])){
	echo "<div class=res>";
	$hora=$_POST["hora"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,fecha,hora,dui,estado FROM citas WHERE hora LIKE '%$hora%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tree><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["ok4"])){
	echo "<div class=res>";
	$estado=$_POST["estado"];
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,fecha,hora,dui,estado FROM citas WHERE estado LIKE '%$estado%'";
	echo $obj->mostrar($sql);
	echo "<br><br><table class=tree><form method=post><tr><td><input type=submit name=otro value=Listo></td></tr></form></table>";
	echo "</div>";
}elseif(isset($_POST["eliminar"])){

	$sql="UPDATE citas SET estado='NULL' WHERE estado LIKE '%Realizada%'";
	$obj->actualizar($sql);
	if ($obj==true) {
			echo "Registro actualizado con exito";
		}else{
			echo "error";
		}
	header("Location:citas.php");
}else{
	echo "<div class=ini>";
	echo "<form method=post>";
		echo "<table align=center class=tbl>";
			echo "<tr><td>Buscar Por</td><td><select name=orden>";
				echo "<option>Nombre de Propietario</option>";
				echo "<option>Tipo de Mascota</option>";
				echo "<option>Fecha</option>";
			echo "<option>Hora</option>";
			echo "<option>Estado</option>";
			echo "</select></td></tr>";
			echo "<tr><td colspan=2 align=center><input type=submit name=enviar value='    Ir    '></td></tr>";
		echo "</table>";
	echo "</form>";
	echo "</div>";
	echo "<div class=res>";
	$sql="SELECT nombre_propietario,apellido_propietario,tel,nombre_mascota,sexo_mascota,tipo_mascota,edad_mascota,fecha,hora,dui,estado FROM citas where estado='pendiente' OR estado='Realizada'";
	echo $obj->mostrar($sql);
	echo "</div>";

	echo "<br><br><form method=post>";
		echo "<table class=tree>";
			echo "<tr><td><input type=submit name=eliminar value='limpiar realizadas'></td></tr>";
		echo "</table>";
	echo "</form>";
}
?>
</div>
