<?php
	session_start();
	include "conexion.php";
	$c=new Conexion();
	$sess=$_SESSION["dui"];
	$suma=0;
	$id=$_SESSION["id"];
	require('fpdf/fpdf.php');


	class PDF extends FPDF
	{
	// Cabecera de página
	function Header()
	{
	    // Logo
	    $this->Image('CSS/ban.jpg',15,8,180);
	    // Arial bold 15
	    $this->Ln(30);
	    $this->SetFont('Arial','B',18);
	    // Movernos a la derecha
	    $this->Cell(60);
	    // Título
	    $this->Cell(70,10,'Detalle de Venta',0,0,'C');
	    // Salto de línea
	    $this->Ln(20);
	    
	}

	// Pie de página
	function Footer()
	{
	    // Posición: a 1,5 cm del final
	    $this->SetY(-15);
	    // Arial italic 8
	    $this->SetFont('Arial','I',8);
	    // Número de página
	    $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
	}
	}

	$fecha=date("Y")."-".date("m")."-".date("d");
	$sql="SELECT * FROM clientes WHERE id_cliente='$sess'";
	$res=$c->consultar($sql);
	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',11);
	while ($row=$res->fetch_assoc()) {

		$pdf->Cell(36,10,'Nombre de Cliente:',0,'C',0);
		$pdf->Cell(-5);
		$pdf->Cell(20,10,$row['nombre_cliente'],0,'C',0);
		$pdf->Cell(-5);
		$pdf->Cell(20,10,$row['apellido_client'],0,'C',0);
		$pdf->Cell(-2);
		$pdf->Cell(36,10,'Telefono:',0,'C',0);

		$pdf->Cell(20,10,$row['tel'],0,'C',0);
		$pdf->Cell(36,10,'Dui:',0,'C',0);
		$pdf->Cell(3);
		$pdf->Cell(20,10,$row['id_cliente'],0,1,'C',0);
	}
	$pdf->Ln(20);
	//echo "$sess".$id;
	$sql1="SELECT nombre_producto,precio,cantidad,subtotal from ventas inner join productos on ventas.id_producto=productos.id_producto inner join pedidos on ventas.id_pedido=pedidos.id_pedido where ventas.id_cliente='$sess' and pedidos.id_pedido=$id";
	$resu=$c->consultar($sql1);
	$pdf->Cell(20);
	$pdf->Cell(85,10,'Producto',1,0,'C',0);
	$pdf->Cell(20,10,'Precio/u',1,0,'C',0);
	$pdf->Cell(20,10,'Cantidad',1,0,'C',0);
	$pdf->Cell(26,10,'Subtotal',1,1,'C',0);
	while ($row=$resu->fetch_assoc()) {
		$pdf->Cell(20);
		$pdf->Cell(85,10,$row['nombre_producto'],1,0,'C',0);
		$pdf->Cell(20,10,$row['precio'],1,0,'C',0);
		$pdf->Cell(20,10,$row['cantidad'],1,0,'C',0);
		$pdf->Cell(26,10,$row['subtotal'],1,1,'C',0);
		$suma+=$row['subtotal'];
	}
		$pdf->Cell(20);
		$pdf->Cell(85,10,'',1,0,'C',0);
		$pdf->Cell(20,10,'',1,0,'C',0);
		$pdf->Cell(20,10,'Total:',1,0,'C',0);
		$pdf->Cell(26,10,$suma,1,1,'C',0);
		
	$pdf->Output();
	unset($_SESSION["dui"]);
?>