<?php
	define ('USUARIO','root');
	define ('CONTRA','');
	define ('SERVIDOR','localhost');
	define ('BASEDATOS','clinica');
?>